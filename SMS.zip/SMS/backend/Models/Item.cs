
public class Item {
    public int ItemId { get; set; }
    public string Title { get; set; }
    public decimal Price { get; set; }
}
