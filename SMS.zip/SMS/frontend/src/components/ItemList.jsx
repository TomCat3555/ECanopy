
import React, { useEffect, useState } from "react";
import axios from "axios";

function ItemList() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get("https://localhost:5001/api/items")
      .then(res => setItems(res.data));
  }, []);

  return (
    <div>
      <h2>Buy & Sell Items</h2>
      {items.map(item => (
        <p key={item.itemId}>{item.title} - ₹{item.price}</p>
      ))}
    </div>
  );
}
export default ItemList;
