
import React, { useEffect, useState } from "react";
import axios from "axios";

function HouseList() {
  const [houses, setHouses] = useState([]);

  useEffect(() => {
    axios.get("https://localhost:5001/api/houses")
      .then(res => setHouses(res.data));
  }, []);

  return (
    <div>
      <h2>Rent / Sell Houses</h2>
      {houses.map(h => (
        <p key={h.houseId}>{h.title} - {h.type} - ₹{h.price}</p>
      ))}
    </div>
  );
}
export default HouseList;
