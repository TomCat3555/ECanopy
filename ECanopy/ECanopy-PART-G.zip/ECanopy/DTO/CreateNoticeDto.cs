﻿namespace ECanopy.DTO
{
    public class CreateNoticeDto
    {
        public string Title { get; set; } = null!;
        public string Message { get; set; } = null!;
    }
}
