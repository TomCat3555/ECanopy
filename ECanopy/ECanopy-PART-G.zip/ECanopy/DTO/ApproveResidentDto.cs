﻿namespace ECanopy.DTO
{
    public class ApproveResidentDto
    {
        public string ResidentEmail { get; set; }
        public string SocietyName { get; set; }
        public string BuildingName { get; set; }
        public string FlatNumber { get; set; }
    }
}
