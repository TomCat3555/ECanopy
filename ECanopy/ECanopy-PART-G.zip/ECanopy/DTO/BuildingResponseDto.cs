﻿namespace ECanopy.DTO
{
    public class BuildingResponseDto
    {
        public string Name { get; set; } = null!;
    }
}
