﻿namespace ECanopy.DTO
{
    public class AssignRoleDto
    {
        public string Email { get; set; }
        public string Role { get; set; }
    }
}
