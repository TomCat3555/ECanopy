﻿namespace ECanopy.DTO
{
    public class CreateBuildingDto
    {
        public string BuildingName { get; set; } = null!;
    }
}
