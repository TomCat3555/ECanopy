﻿namespace ECanopy.DTO
{
    public class CreateComplaintDto
    {
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
    }
}
