﻿using ECanopy.Data;
using ECanopy.DTO;
using ECanopy.Models;
using ECanopy.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ECanopy.Controllers
{
    [ApiController]
    [Route("api/payments")]
    [Authorize]
    public class PaymentController : RwaController
    {
        private readonly IPaymentService _paymentService;

        public PaymentController(
            ApplicationDbContext context,
            IPaymentService paymentService)
            : base(context)
        {
            _paymentService = paymentService;
        }

        // ===============================
        // MAKE PAYMENT (OWNER)
        // ===============================
        [Authorize(Roles = "Resident")]
        [HttpPost]
        public async Task<IActionResult> MakePayment(CreatePaymentDto dto)
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)!;

            var result =
                await _paymentService.PayAsync(userId, dto);

            return Ok(result);
        }

        // ===============================
        // MY PAYMENTS (OWNER)
        // ===============================
        [Authorize(Roles = "Resident")]
        [HttpGet("my")]
        public async Task<IActionResult> MyPayments()
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)!;

            var result =
                await _paymentService.MyAsync(userId);

            return Ok(result);
        }

        // ===============================
        // ALL PAYMENTS (RWA TREASURER)
        // ===============================
        [Authorize(Roles = "RWA_Treasurer")]
        [HttpGet]
        public async Task<IActionResult> AllPayments()
        {
            await LoadRwaContextAsync();

            var result =
                await _paymentService.AllAsync(
                    RwaSocietyId!.Value);

            return Ok(result);
        }
    }
}
