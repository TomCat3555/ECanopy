﻿using ECanopy.DTO;
using ECanopy.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECanopy.Controllers
{
    [ApiController]
    [Route("api/role-requests")]
    [Authorize(Roles = "Resident")]
    public class RoleRequestController : ControllerBase
    {
        private readonly IRoleRequestService _service;

        public RoleRequestController(IRoleRequestService service)
        {
            _service = service;
        }

        // ===============================
        // REQUEST RWA ROLE (NO IDS)
        // ===============================
        [HttpPost]
        public async Task<IActionResult> Create(
            CreateRoleRequestDto dto)
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)!;

            await _service.CreateAsync(
                userId,
                dto.RequestedRole);

            return Ok(new { message = "Role request submitted" });
        }

        // ===============================
        // VIEW MY ROLE REQUESTS
        // ===============================
        [HttpGet("my")]
        public async Task<IActionResult> My()
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)!;

            return Ok(
                await _service.GetMyAsync(userId));
        }
    }
}
