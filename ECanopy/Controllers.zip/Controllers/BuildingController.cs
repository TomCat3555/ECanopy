﻿using ECanopy.Data;
using ECanopy.DTO;
using ECanopy.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECanopy.Controllers
{
    [ApiController]
    [Route("api/buildings")]
    [Authorize(Roles = "RWA_President,RWA_Secretary")]
    public class BuildingController : RwaController
    {
        private readonly IBuildingService _buildingService;

        public BuildingController(
            ApplicationDbContext context,
            IBuildingService buildingService)
            : base(context)
        {
            _buildingService = buildingService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateBuilding(CreateBuildingDto dto)
        {
            await LoadRwaContextAsync();

            var result = await _buildingService.CreateAsync(
                RwaSocietyId!.Value,
                dto);

            return Ok(result);
        }
    }
}
