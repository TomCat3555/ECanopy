﻿using ECanopy.Data;
using ECanopy.DTO;
using ECanopy.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECanopy.Controllers
{
    [ApiController]
    [Route("api/rwa/residents")]
    [Authorize(Roles = "RWA_President")]
    public class RwaResidentApprovalController : RwaController
    {
        private readonly IRwaResidentApprovalService _service;

        public RwaResidentApprovalController(
            ApplicationDbContext context,
            IRwaResidentApprovalService service)
            : base(context)
        {
            _service = service;
        }

        // ===============================
        // VIEW PENDING REQUESTS
        // ===============================
        [HttpGet("pending")]
        public async Task<IActionResult> Pending()
        {
            await LoadRwaContextAsync();

            return Ok(
                await _service.GetPendingAsync(
                    RwaSocietyId!.Value));
        }

        // ===============================
        // APPROVE REQUEST (NO IDS)
        // ===============================
        [HttpPost("approve")]
        public async Task<IActionResult> Approve(
            ProcessResidentJoinRequestDto dto)
        {
            await LoadRwaContextAsync();

            await _service.ApproveAsync(
                RwaSocietyId!.Value,
                dto.UserEmail);

            return Ok(new { message = "Resident approved" });
        }

        // ===============================
        // REJECT REQUEST (NO IDS)
        // ===============================
        [HttpPost("reject")]
        public async Task<IActionResult> Reject(
            ProcessResidentJoinRequestDto dto)
        {
            await LoadRwaContextAsync();

            await _service.RejectAsync(
                RwaSocietyId!.Value,
                dto.UserEmail);

            return Ok(new { message = "Resident rejected" });
        }
    }
}
