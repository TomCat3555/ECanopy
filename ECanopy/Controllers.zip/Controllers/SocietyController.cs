﻿using ECanopy.Data;
using ECanopy.DTO;
using ECanopy.Models;
using ECanopy.Services;
using ECanopy.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ECanopy.Controllers
{
    [ApiController]
    [Route("api/societies")]
    public class SocietyController : ControllerBase
    {
        private readonly ISocietyService _service;

        public SocietyController(ISocietyService service)
        {
            _service = service;
        }

        [Authorize(Roles = "RWA_President,RWA_Secretary")]
        [HttpPost]
        public async Task<IActionResult> CreateSociety(CreateSocietyDto dto)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier)!;

            // ✅ ONLY trust fields that user is allowed to provide
            var society = await _service.CreateAsync(
                userId,
                dto.SocietyName,
                dto.Address
            );

            // ❌ dto.SocietyId is ignored
            // ❌ dto.Owner is ignored
            // ❌ dto.SocietyDescription is ignored

            return Ok(new SocietyResponseDto
            {
                SocietyName = society.SocietyName,
                Address = society.Address,
                Owner = society.RwaMembers
                    .FirstOrDefault(r => r.Role == "RWA_President")?
                    .User.FullName ?? string.Empty
            });
        }
    }

}


