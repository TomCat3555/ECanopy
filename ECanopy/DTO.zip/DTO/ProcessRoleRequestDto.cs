﻿namespace ECanopy.DTO
{
    public class ProcessRoleRequestDto
    {
        public string UserEmail { get; set; } = null!;

    }
}
