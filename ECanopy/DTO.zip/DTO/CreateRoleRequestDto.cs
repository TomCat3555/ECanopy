﻿namespace ECanopy.DTO
{
    public class CreateRoleRequestDto
    {
        public string RequestedRole { get; set; } = null!;
    }
}
