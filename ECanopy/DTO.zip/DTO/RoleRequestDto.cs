﻿namespace ECanopy.DTO
{
    public class RoleRequestDto
    {
        public string RequestedRole { get; set; } = null!;
    }
}
