﻿namespace ECanopy.DTO
{
    public class ProcessResidentJoinRequestDto
    {
        public string UserEmail { get; set; } = null!;
    }
}
