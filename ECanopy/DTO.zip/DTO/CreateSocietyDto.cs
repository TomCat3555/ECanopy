﻿namespace ECanopy.DTO
{
    public class CreateSocietyDto
    {
        public string SocietyName { get; set; } = null!;
        public string Address { get; set; } = null!;
    }
}
