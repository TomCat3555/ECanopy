﻿namespace ECanopy.DTO
{
    public class CreateResidentDto
    {
        public string SocietyName { get; set; }
        public string BuildingName { get; set; }
        public string FlatNumber { get; set; }
        public bool IsOwner { get; set; }
    }
}
