﻿namespace ECanopy.DTO
{
    public class FlatResponseDto
    {
        public string FlatNumber { get; set; } = null!;
    }
}
