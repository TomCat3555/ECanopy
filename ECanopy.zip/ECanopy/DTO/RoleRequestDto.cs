﻿namespace ECanopy.DTO
{
    public class RoleRequestDto
    {
        public int SocietyId { get; set; }
        public string Role { get; set; }
    }
}
