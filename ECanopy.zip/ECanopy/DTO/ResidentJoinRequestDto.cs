﻿namespace ECanopy.DTO
{
    public class ResidentJoinRequestDto
    {
        public string SocietyName { get; set; }
        public string BuildingName { get; set; }
        public string FlatNumber { get; set; }
    }
}
